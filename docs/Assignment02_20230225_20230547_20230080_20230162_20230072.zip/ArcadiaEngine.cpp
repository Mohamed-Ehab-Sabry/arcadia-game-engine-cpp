// ArcadiaEngine.cpp - STUDENT TEMPLATE
// TODO: Implement all the functions below according to the assignment requirements

#include "ArcadiaEngine.h"
#include <algorithm>
#include <queue>
#include <numeric>
#include <climits>
#include <cmath>
#include <cstdlib>
#include <vector>
#include <string>
#include <iostream>
#include <map>
#include <set>

using namespace std;

// =========================================================
// PART A: DATA STRUCTURES (Concrete Implementations)
// =========================================================

// --- 1. PlayerTable (Double Hashing) ---

class ConcretePlayerTable : public PlayerTable
{
private:
    // TODO: Define your data structures here
    // Hint: You'll need a hash table with double hashing collision resolution
    struct Player
    {
        int ID;
        string Name;
        bool is_occupied;
    };
    int H1(int playerId)
    {
        return playerId % 101;
    }
    int H2(int playerId)
    {
        return 13 - (playerId % 13);
    }
    Player playersTable[101];

public:
    ConcretePlayerTable()
    {
        // TODO: Initialize your hash table
        for (auto &p : playersTable)
        {
            p.is_occupied = false;
            p.ID = -1;
            p.Name = "";
        }
    }

    void insert(int playerID, string name) override
    {
        // TODO: Implement double hashing insert
        // Remember to handle collisions using h1(key) + i * h2(key)
        int h1 = H1(playerID);
        int h2 = H2(playerID);
        int i = 0;
        int idx = (h1 + i * h2) % 101;
        while (playersTable[idx].is_occupied && i < 101)
        {
            if(playersTable[idx].is_occupied && playersTable[idx].ID == playerID)
            {
                playersTable[idx].Name = name;
                return;
            }
            idx = (h1 + ++i * h2) % 101;
        }
        if (i >= 101)
        {
            cout << "Table is Full";
            return ;
        }
        playersTable[idx].ID = playerID;
        playersTable[idx].is_occupied = true;
        playersTable[idx].Name = name;
    }

    string search(int playerID) override
    {
        // TODO: Implement double hashing search
        // Return "" if player not found
        int h1 = H1(playerID);
        int h2 = H2(playerID);
        int i = 0;
        while (i < 101)
        {
            int idx = (h1 + i * h2) % 101;
            if (!playersTable[idx].is_occupied)
            {
                return "";
            }
            if (playersTable[idx].ID == playerID)
            {
                return playersTable[idx].Name;
            }
            i++;
        }
        return "";
    }
};

// --- 2. Leaderboard (Skip List) ---

class ConcreteLeaderboard : public Leaderboard
{
private:
    // TODO: Define your skip list node structure and necessary variables
    // Hint: You'll need nodes with multiple forward pointers
    struct Node
    {
        int playerID;
        int score;
        vector<Node *> forward;
        Node(int id, int s, int level)
            : playerID(id), score(s), forward(level, nullptr) {}
    };

    int maxLevel;
    int currentLevel;
    double probability;
    Node *header;
    vector<int> playerScores; 
    int randomLevel()
    {
        int lvl = 0;
        while (((double)rand() / RAND_MAX) < probability && lvl < maxLevel)
        {
            lvl++;
        }
        return lvl;
    }

public:
    ConcreteLeaderboard()
    {
        // TODO: Initialize your skip list
        maxLevel = 16;
        currentLevel = 0;
        probability = 0.5;
        header = new Node(-1, INT_MAX, maxLevel + 1);
        srand(time(nullptr));
        playerScores.resize(200000, -1); 
    }

    void addScore(int playerID, int score) override
    {
        // TODO: Implement skip list insertion
        // Remember to maintain descending order by score

        if (playerID >= playerScores.size()) {
            playerScores.resize(playerID * 2, -1);
        }
        // Remove old score if player exists
        if (playerScores[playerID] != -1) {
            removePlayer(playerID);
        }
        playerScores[playerID] = score;

        vector<Node *> update(maxLevel + 1, nullptr);
        Node *current = header;

        for (int i = currentLevel; i >= 0; i--)
        {
            while (
                current->forward[i] != nullptr &&
                (current->forward[i]->score > score ||
                 (current->forward[i]->score == score &&
                  current->forward[i]->playerID < playerID)))
            {
                current = current->forward[i];
            }
            update[i] = current;
        }

        int lvl = randomLevel();

        if (lvl > currentLevel)
        {
            for (int i = currentLevel + 1; i <= lvl; i++)
                update[i] = header;
            currentLevel = lvl;
        }

        Node *newNode = new Node(playerID, score, lvl + 1);

        for (int i = 0; i <= lvl; i++)
        {
            newNode->forward[i] = update[i]->forward[i];
            update[i]->forward[i] = newNode;
        }
    }

    void removePlayer(int playerID) override
    {
        // TODO: Implement skip list deletion
        Node *target = nullptr;
        Node *prev = header;

        while (prev->forward[0] != nullptr)
        {
            if (prev->forward[0]->playerID == playerID)
            {
                target = prev->forward[0];
                break;
            }
            prev = prev->forward[0];
        }

        if (target == nullptr)
            return;

        // Deleting the node from every level
        for (int i = 0; i <= currentLevel; i++)
        {
            Node *curr = header;
            while (curr->forward[i] != nullptr && curr->forward[i] != target)
            {
                curr = curr->forward[i];
            }

            if (curr->forward[i] == target)
                curr->forward[i] = target->forward[i];
        }

        delete target;

        while (currentLevel > 0 && header->forward[currentLevel] == nullptr)
        {
            currentLevel--;
        }
    }

    vector<int> getTopN(int n) override
    {
        // TODO: Return top N player IDs in descending score order
        vector<int> result;
        Node *current = header->forward[0];

        while (current != nullptr && (int)result.size() < n)
        {
            result.push_back(current->playerID);
            current = current->forward[0];
        }

        return result;
    }
};

// --- 3. AuctionTree (Red-Black Tree) ---

class ConcreteAuctionTree : public AuctionTree
{
private:
    // TODO: Define your Red-Black Tree node structure
    // Hint: Each node needs: id, price, color, left, right, parent pointers
    enum Color
    {
        red,
        black
    };

    class Node
    {
    public:
        int id;
        int price;
        Color color;
        bool Dblack;
        Node *parent;
        Node *left;
        Node *right;

        Node()
        {
            parent = nullptr;
            left = nullptr;
            right = nullptr;
            color = red;
            Dblack = false;
            price = INT_MIN;
            id = INT_MIN;
        }
        Node(int id, int price)
        {
            this->price = price;
            this->id = id;
            color = red;
            Dblack = false;
            parent = nullptr;
            left = nullptr;
            right = nullptr;
        }
        Node(bool isDoubleBlack)
        {
            Dblack = isDoubleBlack;
            color = black;
            parent = nullptr;
            left = nullptr;
            right = nullptr;
            price = INT_MIN;
            id = INT_MIN;
        }
    };

    void leftRotation(Node *node)
    {
        // check if the node or it's child is null
        if (node == nullptr || node->right == nullptr)
            return;
        // saving the right child and it's left subtree
        Node *rightchild = node->right;
        Node *leftgrandchild = rightchild->left;
        // moving the subtree to it's new parent (the main node)
        node->right = leftgrandchild;
        if (leftgrandchild != nullptr)
            leftgrandchild->parent = node;
        // making the rotation and handling the new root of the subtree
        rightchild->left = node;
        rightchild->parent = node->parent;
        if (node->parent == nullptr)
            root = rightchild;
        else if (node == node->parent->right)
            node->parent->right = rightchild;
        else
            node->parent->left = rightchild;
        // changing the parent of the old root
        node->parent = rightchild;
    }
    void rightRotation(Node *node)
    {
        // check if the node or it's child is null
        if (node == nullptr || node->left == nullptr)
            return;
        // saving the right child and it's right subtree
        Node *leftchild = node->left;
        Node *rightgrandchild = leftchild->right;
        // moving the subtree to it's new parent (the main node)
        node->left = rightgrandchild;
        if (rightgrandchild != nullptr)
            rightgrandchild->parent = node;
        // making the rotation and handling the new root of the subtree
        leftchild->right = node;
        leftchild->parent = node->parent;
        if (node->parent == nullptr)
            root = leftchild;
        else if (node == node->parent->left)
            node->parent->left = leftchild;
        else
            node->parent->right = leftchild;
        // changing the parent of the old root
        node->parent = leftchild;
    }

    void fixInsert(Node *node)
    {
        // Base Case
        if (node == nullptr)
            return;
        if (node == root)
        {
            node->color = black;
            return;
        }
        // no violation
        if (node->parent->color == black)
            return;
        Node *parent = node->parent;
        Node *grandparent = node->parent->parent;
        // parent is the root
        if (grandparent == nullptr)
        {
            parent->color = black;
            return;
        }
        if (parent == grandparent->left)
        {
            Node *uncle = grandparent->right;
            if (uncle != nullptr && uncle->color == red)
            {
                // case 1 & 2 : uncle is red. just recoloring and call fix on grandfather
                parent->color = black;
                uncle->color = black;
                grandparent->color = red;
                fixInsert(grandparent);
            }
            else
            {
                // recoloring. same result in case 3 and 4
                grandparent->color = red;
                parent->color = black;
                if (node == parent->right) // case 3 : the problem is left right. changing it to case 4
                    leftRotation(parent);
                rightRotation(grandparent); // case 4 : final rotaion
                if (root)
                    root->color = black;
                return;
            }
        }
        else
        {
            Node *uncle = grandparent->left;
            if (uncle != nullptr && uncle->color == red)
            {
                // case 1 & 2 : uncle is red. just recoloring and call fix on grandfather
                parent->color = black;
                uncle->color = black;
                grandparent->color = red;
                fixInsert(grandparent);
            }
            else
            {
                // recoloring. same result in case 3 and 4
                grandparent->color = red;
                parent->color = black;
                if (node == parent->left) // case 3 : the problem is left right. changing it to case 4
                    rightRotation(parent);
                leftRotation(grandparent); // case 4 : final rotaion
                if (root)
                    root->color = black;
                return;
            }
        }
        if (root)
            root->color = black;
    }

    void fixDelete(Node *node)
    {
        if (node == nullptr)
        {
            cout << "CAN'T FIX A NULL NODE" << endl;
            return;
        }
        if (node == root)
        {
            node->color = black;
            node->Dblack = false;
            cleanNil(node);
            return;
        }
        if (!node->Dblack)
        {
            cleanNil(node);
            return;
        }
        if (node->Dblack && node->color == red)
        {
            node->color = black;
            node->Dblack = false;
            cleanNil(node);
            return;
        }
        if (node->parent->left == node)
        {
            Node *sibling = node->parent->right;
            if (sibling && sibling->color == red) // case 1 : the sibling is red
            {
                // recolor the new parent and grandparent (the old parent and sibling)
                sibling->color = black;
                node->parent->color = red;
                leftRotation(node->parent); // left rotate around the parent
                fixDelete(node);
                return;
            }
            else
            {
                if (sibling && sibling->right && sibling->right->color == red) // case 4 : the far nephew is red
                {
                    sibling->right->color = black;
                    Color temp = sibling->color;
                    sibling->color = node->parent->color;
                    node->parent->color = temp;
                    leftRotation(node->parent);
                    node->Dblack = false;
                    cleanNil(node);
                    return;
                }
                else if (sibling && sibling->left && sibling->left->color == red) // case 3 : the near nephew is red
                {
                    // recolor new sibling and far nephew(near nephew before rotation) (changing it into case 4)
                    sibling->color = red;
                    sibling->left->color = black;
                    rightRotation(sibling); // right rotate around the sibling
                    fixDelete(node);        // call recursively so it'll solve the violation after it became case 4
                    return;
                }
                else // case 2 : sibling exists and his childrens are black
                {
                    node->Dblack = false;
                    node->parent->Dblack = true;
                    if (sibling)
                        sibling->color = red;
                    cleanNil(node);
                    fixDelete(node->parent);
                    return;
                }
            }
        }
        else
        {
            Node *sibling = node->parent->left;
            if (sibling && sibling->color == red) // case 1 : the sibling is red
            {
                // recolor the new parent and grandparent (the old parent and sibling)
                sibling->color = black;
                node->parent->color = red;
                rightRotation(node->parent); // right rotate around the parent
                fixDelete(node);
                return;
            }
            else
            {
                if (sibling && sibling->left && sibling->left->color == red) // case 4 : the far nephew is red
                {
                    sibling->left->color = black;
                    Color temp = sibling->color;
                    sibling->color = node->parent->color;
                    node->parent->color = temp;
                    rightRotation(node->parent);
                    node->Dblack = false;
                    cleanNil(node);
                    return;
                }
                else if (sibling && sibling->right && sibling->right->color == red) // case 3 : the near nephew is red
                {
                    // recolor new sibling and far nephew(near nephew before rotation) (changing it into case 4)
                    sibling->color = red;
                    sibling->right->color = black;
                    leftRotation(sibling); // left rotate around the sibling
                    fixDelete(node);       // call recursively so it'll solve the violation after it became case 4
                    return;
                }
                else // case 2 : sibling exists and his childrens are black
                {
                    node->Dblack = false;
                    node->parent->Dblack = true;
                    if (sibling)
                        sibling->color = red;
                    cleanNil(node);
                    fixDelete(node->parent);
                    return;
                }
            }
        }
        if (root)
        {
            root->color = black;
            root->Dblack = false;
        }
        cleanNil(node);
    }

    void cleanNil(Node *node)
    {
        if (node->id == INT_MIN && !node->Dblack)
        {
            relinkNode(node, nullptr);
            delete node;
        }
    }

    Node *predecessor(Node *node)
    {
        while (node && node->right)
            node = node->right;
        return node;
    }

    void relinkNode(Node *oldNode, Node *newNode)
    {
        if (oldNode->parent == nullptr)
            root = newNode;
        else if (oldNode->parent->right == oldNode)
            oldNode->parent->right = newNode;
        else
            oldNode->parent->left = newNode;
        if (newNode)
            newNode->parent = oldNode->parent;
    }

    Node *searchElement(int id, Node *node)
    {
        if (node == nullptr)
            return nullptr;
        if (node->id == id)
            return node;
        Node *leftResult = searchElement(id, node->left);
        if (leftResult != nullptr)
            return leftResult;
        return searchElement(id, node->right);
    }

    void clear(Node *node)
    {
        if (!node)
            return;
        clear(node->left);
        clear(node->right);
        delete node;
    }

    Node *root;

public:
    ConcreteAuctionTree()
    {
        // TODO: Initialize your Red-Black Tree
        root = nullptr;
    }

    void insertItem(int itemID, int price) override
    {
        // TODO: Implement Red-Black Tree insertion
        // Remember to maintain RB-Tree properties with rotations and recoloring
        Node *node = new Node(itemID, price);
        if (root == nullptr)
        {
            node->color = black;
            root = node;
            return;
        }
        Node *current = root;
        Node *parent = nullptr;
        while (current != nullptr)
        {
            parent = current;
            if (price > current->price || (price == current->price && itemID > current->id))
            {
                current = current->right;
            }
            else
            {
                current = current->left;
            }
        }
        node->parent = parent;
        if (node->price > parent->price)
            parent->right = node;
        else
            parent->left = node;
        if (parent->color == red)
            fixInsert(node);
    }

    void deleteItem(int itemID) override
    {
        // TODO: Implement Red-Black Tree deletion
        // This is complex - handle all cases carefully
        Node *node = searchElement(itemID, root);
        // if the value doesn't exist in the tree
        if (node == nullptr)
        {
            // cout << "THIS ITEM DOES NOT EXISTS!!!!" << endl;
            return;
        }
        // finding the predecessor of the node and save it in newNode, if the node has one child the newNode will be the node itself
        Node *newNode = node;
        if (node->left && node->right)
            newNode = predecessor(node->left);
        // copying the value of the predecessor into the node, now i need to delete the newNode
        node->price = newNode->price;
        node->id = newNode->id;
        // if it has one child (it can have at most one child since it's the presuccessor)
        if (newNode->left || newNode->right)
        {
            Node *newChild = newNode->left ? newNode->left : newNode->right; // saving the child to link it with the newNode's parent
            relinkNode(newNode, newChild);                                   // deleting the newNode from the tree
            if (newNode->color == black)
            {
                newChild->Dblack = true;
                fixDelete(newChild);
            }
            delete newNode;
        }
        else // if it has no children
        {
            if (newNode->color == black) // if it's color is black, make a delusional node (a NIL node) that is double balck and link it in the node's place
            {
                Node *newChild = new Node(true);
                relinkNode(newNode, newChild);
                delete newNode;
                fixDelete(newChild);
            }
            else // if it's color is red (note that it's a leaf), just reassign the parent pointer and delete the node
            {
                relinkNode(newNode, nullptr);
                delete newNode;
                return;
            }
        }
    }

    ~ConcreteAuctionTree()
    {
        clear(root);
    }
};

// =========================================================
// PART B: INVENTORY SYSTEM (Dynamic Programming)
// =========================================================

int InventorySystem::optimizeLootSplit(int n, vector<int> &coins)
{
    int sum = 0;
    int diff = INT_MAX;

    for (int i = 0; i < n; i++)
    {
        sum += coins[i];
    }
    int target = sum/2;

    vector<vector<bool>>dp(n+1,vector<bool>(target+1));

    dp[0][0] = 1;

    for (int i = 1; i <= n; i++)
    {
        for (int j = 0; j <= target; j++)
        {
            dp[i][j] = dp[i-1][j];
            if(j - coins[i-1] >= 0 && dp[i-1][j - coins[i-1]] == 1){
                dp[i][j] = 1;
            }
        }
    }

    for (int i = 0; i <= target; i++)
    {
        if(dp[n][i]){
            diff = min(diff, abs((sum - i) - i));
        }
    }

    return diff;
}

int InventorySystem::maximizeCarryValue(int capacity, vector<pair<int, int>> &items)
{
    // TODO: Implement 0/1 Knapsack using DP
    // items = {weight, value} pairs
    // Return maximum value achievable within capacity

    int num_of_items = items.size();
    vector<vector<int>> best_pos_values(num_of_items + 1, vector<int>(capacity + 1, 0));
    for (int i = 1; i <= num_of_items; i++)
    {
        for (int j = 1; j <= capacity; j++)
        {
            int weight = items[i - 1].first;
            int value = items[i - 1].second;
            int prev_item_value = best_pos_values[i - 1][j];
            if (weight <= j)
            {
                int prev_best_pos_value = best_pos_values[i - 1][j - weight];
                if (value + prev_best_pos_value > prev_item_value)
                {
                    best_pos_values[i][j] = value + prev_best_pos_value;
                }
                else
                {
                    best_pos_values[i][j] = prev_item_value;
                }
            }
            else
            {
                best_pos_values[i][j] = prev_item_value;
            }
        }
    }

    return best_pos_values[num_of_items][capacity];
}

long long InventorySystem::countStringPossibilities(string s)
{
    // TODO: Implement string decoding DP
    // Rules: "uu" can be decoded as "w" or "uu"
    //        "nn" can be decoded as "m" or "nn"
    // Count total possible decodings
    if (s.length() == 0)
        return 1; 
    if(s.find('m') != string::npos || s.find('w') != string::npos)
        return 0;
    const long long mod = 1e9 + 7;
    int n = s.length();
    long long ans[n + 1] = {1};
    s = ' ' + s;
    for (int i = 1; i <= n; i++)
    {
        if ((s[i - 1] == 'u' || s[i - 1] == 'n') && s[i - 1] == s[i])
            ans[i] = (ans[i - 1] % mod + ans[i - 2] % mod) % mod;
        else
            ans[i] = ans[i - 1];
    }
    return ans[n];
}

// =========================================================
// PART C: WORLD NAVIGATOR (Graphs)
// =========================================================

bool WorldNavigator::pathExists(int n, vector<vector<int>> &edges, int source, int dest)
{
    // TODO: Implement path existence check using BFS or DFS
    // edges are bidirectional

    vector<vector<int>> neighbors(n);

    for (auto &road : edges)
    {
        int first_city = road[0];
        int second_city = road[1];

        neighbors[first_city].push_back(second_city);
        neighbors[second_city].push_back(first_city);
    }

    vector<bool> visited(n, 0);
    queue<int> visiting;
    visiting.push(source);
    visited[source] = true;
    int current_city = 0;

    while (!visiting.empty())
    {
        current_city = visiting.front();
        visiting.pop();

        if (dest == current_city)
        {
            return true;
        }

        for (auto &neighbor : neighbors[current_city])
        {
            if (visited[neighbor] == true)
            {
                continue;
            }
            visited[neighbor] = true;
            visiting.push(neighbor);
        }
    }

    return false;
}

long long WorldNavigator::minBribeCost(int n, int m, long long goldRate, long long silverRate,
                                       vector<vector<int>> &roadData)
{
    vector<vector<pair<int, long long>>> adj(n + 1);
    vector<bool> visited(n + 1);

    for (int i = 0; i < m; i++)
    {
        int u = roadData[i][0], v = roadData[i][1];
        long long weight = 1LL * roadData[i][2] * goldRate + 1LL * roadData[i][3] * silverRate;
        adj[u].push_back({v, weight});
        adj[v].push_back({u, weight});
    }

    priority_queue<pair<long long, int>, vector<pair<long long, int>>, greater<pair<long long, int>>> pq;

    pq.push({0, 1});

    long long total_cost = 0;
    int visited_cities = 0;
    while (visited_cities < n && !pq.empty())
    {

        long long weight = pq.top().first;
        int city = pq.top().second;
        pq.pop();

        if (visited[city])
            continue;

        visited[city] = 1;
        visited_cities++;
        total_cost += weight;
        for (auto u : adj[city])
        {
            if (!visited[u.first])
            {
                pq.push({u.second, u.first});
            }
        }
    }

    if (visited_cities == n)
        return total_cost;

    return -1;
}

string WorldNavigator::sumMinDistancesBinary(int n, vector<vector<int>> &roads)
{
    // TODO: Implement All-Pairs Shortest Path (Floyd-Warshall)
    // Sum all shortest distances between unique pairs (i < j)
    // Return the sum as a binary string
    // Hint: Handle large numbers carefully

    vector<vector<long long>> shortest_path(n, vector<long long>(n, LLONG_MAX));
    for (int i = 0; i < n; i++)
    {
        shortest_path[i][i] = 0;
    }

    for (auto &road : roads)
    {
        int u = road[0];
        int v = road[1];
        long long w = road[2];
        shortest_path[u][v] = min(w, shortest_path[u][v]);
        shortest_path[v][u] = min(w, shortest_path[v][u]);
    }

    for (int k = 0; k < n; k++)
    {
        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                if (shortest_path[i][k] == LLONG_MAX || shortest_path[k][j] == LLONG_MAX)
                {
                    continue;
                }

                if (shortest_path[i][j] > shortest_path[i][k] + shortest_path[k][j])
                {
                    shortest_path[i][j] = shortest_path[i][k] + shortest_path[k][j];
                }
            }
        }
    }

    long long sum = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (shortest_path[i][j] == LLONG_MAX)
            {
                continue;
            }
            sum += shortest_path[i][j];
        }
    }

    string sum_string = "";

    if (sum == 0)
    {
        sum_string = "0";
    }

    while (sum > 0)
    {
        if (sum & 1)
        {
            sum_string += "1";
        }
        else
        {
            sum_string += "0";
        }
        sum >>= 1;
    }
    reverse(sum_string.begin(), sum_string.end());

    return sum_string;
}

// =========================================================
// PART D: SERVER KERNEL (Greedy)
// =========================================================

int ServerKernel::minIntervals(vector<char> &tasks, int n)
{
    // TODO: Implement task scheduler with cooling time
    // Same task must wait 'n' intervals before running again
    // Return minimum total intervals needed (including idle time)
    // Hint: Use greedy approach with frequency counting
    if(tasks.size() == 0)
        return 0;
    vector<int> freq(26);
    for (char c : tasks)
    {
        freq[c - 'A']++;
    }
    int max_frequent = *max_element(freq.begin(), freq.end());
    int max_count = 0;
    for (int i : freq)
    {
        if (i == max_frequent)
            max_count++;
    }
    int total_intervals = (max_frequent - 1) * (n + 1) + max_count;

    return max((int)tasks.size(), total_intervals);
}

// =========================================================
// FACTORY FUNCTIONS (Required for Testing)
// =========================================================

extern "C"
{
    PlayerTable *createPlayerTable()
    {
        return new ConcretePlayerTable();
    }

    Leaderboard *createLeaderboard()
    {
        return new ConcreteLeaderboard();
    }

    AuctionTree *createAuctionTree()
    {
        return new ConcreteAuctionTree();
    }
}
